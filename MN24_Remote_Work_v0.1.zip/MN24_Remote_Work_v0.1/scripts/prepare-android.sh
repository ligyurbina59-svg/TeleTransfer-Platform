#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
npm install
npm run build
if [ ! -d android ]; then
  npx cap add android
fi
npx cap sync android
echo
echo "Capacitor sincronizado. Para compilar APK necesitas JDK, Android SDK y Gradle."
echo "Desde el directorio android, ejecuta: ./gradlew assembleDebug"
mkdir -p releases
if [ -f android/app/build/outputs/apk/debug/app-debug.apk ]; then
  cp android/app/build/outputs/apk/debug/app-debug.apk releases/MN24-Remote-Work-debug.apk
  echo "APK copiado a releases/MN24-Remote-Work-debug.apk"
else
  echo "Todavía no hay APK. Ejecuta: cd android && ./gradlew assembleDebug"
fi
