# Estado real del proyecto

## Código fuente incluido
- Aplicación web móvil con panel, oportunidades, clientes y seguimiento de solicitudes.
- Datos guardados localmente en el navegador mediante localStorage.
- Exportación de respaldo JSON.
- PWA con manifest y service worker básico.
- Configuración inicial de Capacitor y script de preparación Android.

## No incluido / no verificado
- No se incluye APK compilado.
- No existe backend multiusuario ni sincronización en la nube.
- No hay autenticación, permisos por rol, cifrado de datos sensibles ni CRM compartido.
- No se recolectan vacantes automáticamente ni se verifica la legitimidad de ofertas.
- No hay pagos, facturación, chat, calendario sincronizado ni notificaciones push.
- No hay publicación en Google Play.

## Antes de producción
1. Crear backend con autenticación y base de datos.
2. Implementar privacidad, copias de seguridad y validación de datos.
3. Probar PWA y APK en Android real.
4. Añadir términos, política de privacidad y soporte.
5. Configurar firma, iconos, capturas y publicación.
