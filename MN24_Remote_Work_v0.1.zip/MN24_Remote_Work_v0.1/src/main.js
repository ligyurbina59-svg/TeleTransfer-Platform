const STORAGE_KEY = "mn24-remote-work-v1";
const initialState = { opportunities: [], clients: [], applications: [] };
let state = loadState();
let currentType = "opportunities";

const $ = (id) => document.getElementById(id);
const escapeHtml = (value = "") => String(value).replace(/[&<>"']/g, (c) => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
function loadState() {
  try { return { ...initialState, ...JSON.parse(localStorage.getItem(STORAGE_KEY) || "{}") }; }
  catch { return structuredClone(initialState); }
}
function saveState() { localStorage.setItem(STORAGE_KEY, JSON.stringify(state)); render(); }
function money(n) { return new Intl.NumberFormat("en-US", { style:"currency", currency:"USD", maximumFractionDigits:2 }).format(Number(n)||0); }
function showView(name) {
  document.querySelectorAll(".view").forEach(v => v.classList.add("hidden"));
  $("view-" + name).classList.remove("hidden");
  document.querySelectorAll(".nav-item").forEach(b => b.classList.toggle("active", b.dataset.view === name));
  const titles = {dashboard:"Panel de trabajo remoto",opportunities:"Oportunidades remotas",clients:"Clientes",applications:"Solicitudes y proyectos"};
  $("page-title").textContent = titles[name] || "MN24 Remote Work";
  if (name === "dashboard") renderDashboard();
}
document.querySelectorAll("[data-view]").forEach(b => b.addEventListener("click", () => showView(b.dataset.view)));
document.querySelectorAll("[data-go]").forEach(b => b.addEventListener("click", () => showView(b.dataset.go)));

const schemas = {
  opportunities: { title:"Nueva oportunidad", fields:[
    ["title","Título de la vacante o proyecto","text",true],
    ["company","Empresa o cliente","text",true],
    ["type","Tipo","select",true,["Trabajo remoto","Freelance","Proyecto puntual","Práctica"]],
    ["url","Enlace oficial","url",false],
    ["pay","Pago estimado en USD","number",false],
    ["status","Estado","select",true,["Guardada","Por postular","Postulada","Entrevista","Descartada","Ganada"]],
    ["notes","Notas","textarea",false]
  ]},
  clients: { title:"Nuevo cliente", fields:[
    ["name","Nombre del cliente","text",true],["company","Empresa","text",false],
    ["email","Correo de contacto","email",false],["service","Servicio ofrecido","text",true],
    ["value","Valor estimado en USD","number",false],["next","Próximo paso","text",false],
    ["status","Estado","select",true,["Nuevo contacto","Conversación","Propuesta enviada","Activo","Cerrado"]]
  ]},
  applications: { title:"Nueva solicitud o proyecto", fields:[
    ["title","Vacante o proyecto","text",true],["company","Empresa o cliente","text",true],
    ["kind","Tipo","select",true,["Empleo","Freelance","Cliente directo"]],
    ["status","Estado","select",true,["Preparar solicitud","Postulada","Entrevista","Propuesta enviada","Ganada","Rechazada"]],
    ["date","Fecha de seguimiento","date",false],["income","Ingreso acordado en USD","number",false],
    ["notes","Notas / próximo paso","textarea",false]
  ]}
};
function openForm(type) {
  currentType = type;
  const schema = schemas[type];
  $("dialog-title").textContent = schema.title;
  $("form-fields").innerHTML = schema.fields.map(([name,label,kind,required,options]) => {
    let control = "";
    if (kind === "select") control = `<select name="${name}" ${required?"required":""}>${options.map(o=>`<option>${escapeHtml(o)}</option>`).join("")}</select>`;
    else if (kind === "textarea") control = `<textarea name="${name}" placeholder="Escribe detalles útiles"></textarea>`;
    else control = `<input name="${name}" type="${kind}" ${required?"required":""} ${kind==="number"?'min="0" step="0.01"':""} placeholder="${kind==="url"?"https://":""}">`;
    return `<div class="field"><label for="${name}">${escapeHtml(label)}${required?" *":""}</label>${control}</div>`;
  }).join("");
  $("record-form").dataset.type = type;
  $("record-dialog").showModal();
}
$("add-opp-open").addEventListener("click", () => openForm("opportunities"));
$("add-client-open").addEventListener("click", () => openForm("clients"));
$("add-app-open").addEventListener("click", () => openForm("applications"));
$("dialog-close").addEventListener("click", () => $("record-dialog").close());
$("cancel-btn").addEventListener("click", () => $("record-dialog").close());
$("record-form").addEventListener("submit", (event) => {
  event.preventDefault();
  const form = new FormData(event.currentTarget);
  const item = Object.fromEntries(form.entries());
  item.id = crypto.randomUUID ? crypto.randomUUID() : String(Date.now());
  item.createdAt = new Date().toISOString();
  if (item.url && !/^https?:\/\//i.test(item.url)) { alert("El enlace debe comenzar con https:// o http://"); return; }
  state[currentType].unshift(item);
  $("record-dialog").close();
  event.currentTarget.reset();
  saveState();
});
function card(type, item) {
  const title = item.title || item.name || "Sin título";
  const sub = item.company || item.service || "";
  const status = item.status || "Registrado";
  const amount = item.pay || item.value || item.income;
  const link = item.url ? `<p><a href="${escapeHtml(item.url)}" target="_blank" rel="noopener noreferrer">Abrir enlace oficial ↗</a></p>` : "";
  const details = [item.notes,item.next,item.email,item.service].filter(Boolean).map(escapeHtml).join(" · ");
  return `<article class="record-card"><h3>${escapeHtml(title)}</h3><p>${escapeHtml(sub)}</p><div class="record-meta"><span class="pill">${escapeHtml(status)}</span>${item.kind?`<span class="pill">${escapeHtml(item.kind)}</span>`:""}${amount?`<span class="pill">${money(amount)}</span>`:""}</div>${link}${details?`<p>${details}</p>`:""}<div class="record-actions"><button class="small-button" data-edit-status="${escapeHtml(item.id)}" data-type="${type}">Cambiar estado</button><button class="small-button danger" data-delete="${escapeHtml(item.id)}" data-type="${type}">Eliminar</button></div></article>`;
}
function renderList(type, targetId) {
  const items = state[type];
  $(targetId).innerHTML = items.length ? items.map(i=>card(type,i)).join("") : `<div class="panel empty-state">Aún no hay registros. Pulsa «Añadir» para crear el primero.</div>`;
}
function renderDashboard() {
  $("stat-opps").textContent = state.opportunities.length;
  $("stat-clients").textContent = state.clients.length;
  $("stat-apps").textContent = state.applications.filter(a=>!["Ganada","Rechazada"].includes(a.status)).length;
  const income = [...state.clients.map(x=>x.value),...state.applications.filter(x=>x.status==="Ganada").map(x=>x.income)].reduce((sum,n)=>sum+(Number(n)||0),0);
  $("stat-income").textContent = money(income);
  const recent = [...state.opportunities,...state.clients,...state.applications].sort((a,b)=>(b.createdAt||"").localeCompare(a.createdAt||"")).slice(0,4);
  $("recent-list").innerHTML = recent.length ? recent.map(x=>`<p><strong>${escapeHtml(x.title||x.name||"Registro")}</strong><br><span class="muted">${escapeHtml(x.company||x.service||"")} · ${escapeHtml(x.status||"Guardado")}</span></p>`).join("") : "Todavía no hay registros. Añade tu primera oportunidad o cliente.";
}
document.addEventListener("click", (event) => {
  const del = event.target.closest("[data-delete]");
  if (del) {
    const {type,id} = del.dataset;
    if (confirm("¿Eliminar este registro?")) { state[type] = state[type].filter(x=>x.id!==id); saveState(); }
    return;
  }
  const statusBtn = event.target.closest("[data-edit-status]");
  if (statusBtn) {
    const {type,id} = statusBtn.dataset;
    const item = state[type].find(x=>x.id===id);
    const options = schemas[type].fields.find(f=>f[0]==="status")[4];
    const next = prompt("Nuevo estado:\n"+options.map((o,i)=>`${i+1}. ${o}`).join("\n"), item.status || options[0]);
    if (next && options.includes(next)) { item.status=next; saveState(); }
    else if (next) alert("Selecciona uno de los estados de la lista.");
  }
});
function render() {
  renderList("opportunities","opportunity-list");
  renderList("clients","client-list");
  renderList("applications","application-list");
  renderDashboard();
}
$("export-btn").addEventListener("click", () => {
  const blob = new Blob([JSON.stringify({exportedAt:new Date().toISOString(),...state},null,2)],{type:"application/json"});
  const a = document.createElement("a"); a.href=URL.createObjectURL(blob); a.download="mn24-remote-work-backup.json"; a.click(); URL.revokeObjectURL(a.href);
});
render();
if ("serviceWorker" in navigator && location.protocol.startsWith("http")) navigator.serviceWorker.register("/sw.js").catch(()=>{});
