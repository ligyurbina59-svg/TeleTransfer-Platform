# MN24 Remote Work v0.1

MVP móvil-first para organizar oportunidades remotas, clientes y postulaciones dentro del ecosistema MN24 Studios IA.

## Incluye
- Panel de actividad y resumen de ingresos manuales.
- Registro de oportunidades con enlace oficial, pago estimado y estado.
- CRM sencillo de clientes y servicios.
- Seguimiento de solicitudes y proyectos.
- Exportación de datos a JSON.
- PWA básica y configuración inicial de Capacitor.

## Requisitos
- Node.js LTS y npm.
- Para APK: JDK compatible, Android SDK/build-tools y Gradle disponible por el proyecto Android.

## Ejecutar localmente
```bash
npm install
npm run dev
```
Abre la URL que Vite muestre. En Replit, ejecuta `npm run dev -- --host 0.0.0.0`.

## Construir versión web
```bash
npm run build
npm run preview
```

## Preparar Android
```bash
npm install
npm run build
npx cap add android
npx cap sync android
cd android
./gradlew assembleDebug
```
Si el directorio `android/` ya existe, omite `npx cap add android`.

El APK de depuración suele quedar en `android/app/build/outputs/apk/debug/app-debug.apk`.
Para distribuirlo, debes probarlo y crear una compilación firmada de release.

## Advertencia de datos
Este MVP guarda datos en el navegador del dispositivo. No sincroniza entre teléfono y Replit ni entre usuarios. No guardes contraseñas, documentos de identidad ni información financiera sensible.

## Estado
Este ZIP contiene código fuente, no un APK compilado. Revisa `docs/STATUS.md` para el estado y los requisitos pendientes.
